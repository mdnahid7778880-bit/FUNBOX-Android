package com.funbox.entertainment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

val DarkPurple = Color(0xFF0F051D)
val AccentPurple = Color(0xFF7C3AED)
val ElectricBlue = Color(0xFF06B6D4)
val NeonCyan = Color(0xFF38BDF8)
val CardBg = Color(0xFF1E1035)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = AccentPurple,
                    secondary = ElectricBlue,
                    background = DarkPurple,
                    surface = CardBg
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FunboxApp()
                }
            }
        }
    }
}

@Composable
fun FunboxApp() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { FunboxBottomNav(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen(navController) }
            composable("roast") { RoastScreen() }
            composable("meme") { MemeScreen() }
            composable("quiz") { QuizScreen() }
            composable("wheel") { WheelScreen() }
            composable("games") { GamesScreen() }
            composable("party") { PartyScreen() }
            composable("profile") { ProfileScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}

@Composable
fun FunboxBottomNav(navController: NavController) {
    NavigationBar(containerColor = Color(0xFF12072B)) {
        NavigationBarItem(
            selected = true,
            onClick = { navController.navigate("home") },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 10.sp) }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("games") },
            icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Games") },
            label = { Text("Games", fontSize = 10.sp) }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("party") },
            icon = { Icon(Icons.Default.Face, contentDescription = "Party") },
            label = { Text("Party", fontSize = 10.sp) }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("profile") },
            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
            label = { Text("Profile", fontSize = 10.sp) }
        )
    }
}

@Composable
fun HomeScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Hero Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "FUNBOX",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = ElectricBlue
                )
                Text(
                    text = "Less Boring, More Laughing! 😂",
                    fontSize = 14.sp,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid of Entertainment Tools
        Text("Popular Tools", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { navController.navigate("roast") },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)
            ) {
                Text("AI Roast 🔥")
            }
            Button(
                onClick = { navController.navigate("meme") },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
            ) {
                Text("Meme 🎨")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Developer Footer (Included at bottom of scrollable content)
        DeveloperFooter()
    }
}

@Composable
fun RoastScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("AI Roast Master", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Friendly, safe & hilarious roasts for friends", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))
        DeveloperFooter()
    }
}

@Composable
fun MemeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Meme Factory", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun QuizScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Funny Quiz", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun WheelScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Random Wheel", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun GamesScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Offline Mini Games", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun PartyScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Friends & Party Mode", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun ProfileScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Profile & Achievements", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        DeveloperFooter()
    }
}

@Composable
fun DeveloperFooter() {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp, bottom = 32.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x337C3AED)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Developed By Shuvo Nahid",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Founder & Developer",
                fontSize = 12.sp,
                color = AccentPurple,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Clickable WhatsApp contact row with Android Intent.ACTION_VIEW
            Row(
                modifier = Modifier
                    .background(Color(0x2210B981), RoundedCornerShape(8.dp))
                    .clickable {
                        val whatsappUri = Uri.parse("https://wa.me/8801918732722")
                        val intent = Intent(Intent.ACTION_VIEW, whatsappUri)
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // Fallback to browser
                            val browserIntent = Intent(Intent.ACTION_VIEW, whatsappUri)
                            context.startActivity(browserIntent)
                        }
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "WhatsApp Contact: +8801918732722",
                    color = Color(0xFF34D399),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "© 2026 FUNBOX. All Rights Reserved.",
                fontSize = 10.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
        }
    }
}
