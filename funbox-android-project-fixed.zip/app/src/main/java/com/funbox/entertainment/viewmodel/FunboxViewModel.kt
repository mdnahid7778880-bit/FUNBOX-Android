package com.funbox.entertainment.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.funbox.entertainment.data.GameRecord
import com.funbox.entertainment.data.GameRecordDao
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class FunboxUiState(
    val language: String = "bn",
    val isDarkMode: Boolean = true,
    val streakDays: Int = 3,
    val xp: Int = 120,
    val level: Int = 1,
    val isDailyClaimed: Boolean = false
)

class FunboxViewModel(private val dao: GameRecordDao? = null) : ViewModel() {
    private val _uiState = MutableStateFlow(FunboxUiState())
    val uiState: StateFlow<FunboxUiState> = _uiState.asStateFlow()

    fun setLanguage(lang: String) {
        _uiState.value = _uiState.value.copy(language = lang)
    }

    fun toggleTheme() {
        _uiState.value = _uiState.value.copy(isDarkMode = !_uiState.value.isDarkMode)
    }

    fun addXp(amount: Int) {
        val currentXp = _uiState.value.xp + amount
        val newLevel = (currentXp / 100) + 1
        _uiState.value = _uiState.value.copy(xp = currentXp, level = newLevel)
    }

    fun saveGameResult(gameId: String, title: String, score: Int, result: String) {
        viewModelScope.launch {
            dao?.insertRecord(
                GameRecord(
                    gameId = gameId,
                    gameTitle = title,
                    score = score,
                    result = result
                )
            )
            addXp(if (result == "win") 30 else 10)
        }
    }
}
