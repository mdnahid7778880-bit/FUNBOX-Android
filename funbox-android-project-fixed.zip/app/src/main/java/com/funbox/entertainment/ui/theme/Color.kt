package com.funbox.entertainment.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// FUNBOX Theme Colors
val DarkBackground = Color(0xFF0B0518)
val DarkSurface = Color(0xFF16092E)
val ElectricBlue = Color(0xFF00D2FF)
val NeonPurple = Color(0xFF9D4EDD)
val AccentPink = Color(0xFFF72585)
val CyanGlow = Color(0xFF22D3EE)
val EmeraldWin = Color(0xFF10B981)
