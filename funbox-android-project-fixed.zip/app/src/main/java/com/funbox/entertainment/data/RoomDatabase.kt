package com.funbox.entertainment.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "game_history")
data class GameRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameId: String,
    val gameTitle: String,
    val score: Int,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface GameRecordDao {
    @Query("SELECT * FROM game_history ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<GameRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: GameRecord)

    @Query("DELETE FROM game_history")
    suspend fun clearHistory()
}

@Database(entities = [GameRecord::class], version = 1, exportSchema = false)
abstract class FunboxDatabase : RoomDatabase() {
    abstract fun gameRecordDao(): GameRecordDao
}
